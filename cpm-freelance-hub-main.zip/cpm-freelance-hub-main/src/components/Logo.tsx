
import React from "react";

const Logo = ({ size = "medium" }: { size?: "small" | "medium" | "large" }) => {
  let dimensions;
  switch (size) {
    case "small":
      dimensions = "w-8 h-8";
      break;
    case "large":
      dimensions = "w-24 h-24";
      break;
    default:
      dimensions = "w-16 h-16";
  }

  return (
    <div className="flex items-center justify-center">
      <img 
        src="/lovable-uploads/636534d1-8849-4337-97ad-bde366352e9a.png" 
        alt="CPM Work Online Logo" 
        className={`${dimensions} rounded-full`} 
      />
    </div>
  );
};

export default Logo;
