
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

type BackButtonProps = {
  className?: string;
};

const BackButton = ({ className = "" }: BackButtonProps) => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1); // Go back to previous page
  };

  return (
    <button
      onClick={handleBack}
      className={`absolute top-6 left-6 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors ${className}`}
      aria-label="Go back"
    >
      <ArrowLeft className="h-6 w-6 text-white" />
    </button>
  );
};

export default BackButton;
