
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "@/context/UserContext";
import { toast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";

const SearchProfile = () => {
  const [searchUsername, setSearchUsername] = useState("");
  const { findUser } = useUser();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchUsername.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username to search",
        variant: "destructive",
      });
      return;
    }

    const user = findUser(searchUsername);
    if (!user) {
      toast({
        title: "User Not Found",
        description: "No user with that username exists",
        variant: "destructive",
      });
      return;
    }

    // Navigate to the profile page of the found user
    navigate(`/profile/${searchUsername}`);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cpm-blue to-cpm-black text-white">
      <BackButton />
      <div className="w-full max-w-md mx-auto p-6">
        <h1 className="text-3xl font-bold text-center mb-8">Search Profile</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="searchUsername" className="block text-sm font-medium">
              Search Username
            </label>
            <input
              id="searchUsername"
              type="text"
              value={searchUsername}
              onChange={(e) => setSearchUsername(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-600 bg-gray-800 text-white"
              placeholder="Enter username to search"
            />
          </div>
          
          <button
            type="submit"
            className="w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Search
          </button>
        </form>
      </div>
    </div>
  );
};

export default SearchProfile;
