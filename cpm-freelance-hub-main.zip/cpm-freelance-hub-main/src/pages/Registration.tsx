
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "@/context/UserContext";
import { toast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";

const Registration = () => {
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [bkashNumber, setBkashNumber] = useState("");
  const { addUser, findUser } = useUser();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName.trim() || !username.trim() || !bkashNumber.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    // Check if username already exists
    if (findUser(username)) {
      toast({
        title: "Error",
        description: "Username already exists. Please choose another one.",
        variant: "destructive",
      });
      return;
    }

    // Add the new user
    const newUser = addUser({ fullName, username, bkashNumber });
    
    toast({
      title: "Success",
      description: "Registration successful!",
    });

    // Redirect to profile page
    setTimeout(() => {
      navigate(`/profile/${username}`);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cpm-blue to-cpm-black text-white">
      <BackButton />
      <div className="w-full max-w-md mx-auto p-6">
        <h1 className="text-3xl font-bold text-center mb-8">Registration</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="fullName" className="block text-sm font-medium">
              Full Name
            </label>
            <input
              id="fullName"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-600 bg-gray-800 text-white"
              placeholder="Enter your full name"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="username" className="block text-sm font-medium">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-600 bg-gray-800 text-white"
              placeholder="Choose a username"
            />
            <p className="text-xs text-gray-400">
              This will be added to your work links: https://101000.shop/92af22c7480006e3af1d/2bb8de396d/?placementName={username}
            </p>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="bkashNumber" className="block text-sm font-medium">
              Bkash Namber
            </label>
            <input
              id="bkashNumber"
              type="text"
              value={bkashNumber}
              onChange={(e) => setBkashNumber(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-600 bg-gray-800 text-white"
              placeholder="Enter your Bkash number"
            />
          </div>
          
          <button
            type="submit"
            className="w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Registration
          </button>
        </form>
      </div>
    </div>
  );
};

export default Registration;
