
import { Link } from "react-router-dom";
import Logo from "@/components/Logo";

const HomePage = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cpm-green to-cpm-black text-white">
      <div className="w-full max-w-md mx-auto text-center p-6">
        <h1 className="text-4xl font-bold mb-6">Cpm Work Online</h1>
        
        <Logo size="large" />
        
        <h2 className="text-2xl font-semibold mt-6 mb-10">Welcome To The Freelancing Bot</h2>
        
        <div className="space-y-4">
          <Link 
            to="/search" 
            className="block w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Work Now
          </Link>
          
          <Link 
            to="/registration" 
            className="block w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Registration
          </Link>
          
          <Link 
            to="/admin" 
            className="block w-full py-3 px-6 mt-8 bg-cpm-blue text-white font-bold rounded-lg hover:bg-blue-600 transition-colors"
          >
            Admin Panel
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
