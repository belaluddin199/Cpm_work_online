
import { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useUser } from "@/context/UserContext";
import { toast } from "@/components/ui/use-toast";
import Logo from "@/components/Logo";
import BackButton from "@/components/BackButton";

const ProfileDetails = () => {
  const { username } = useParams<{ username: string }>();
  const { findUser, setCurrentUser } = useUser();
  const navigate = useNavigate();
  
  const user = username ? findUser(username) : null;
  
  useEffect(() => {
    if (!user) {
      toast({
        title: "Error",
        description: "User not found",
        variant: "destructive",
      });
      navigate("/search");
      return;
    }
    
    // Set current user in context
    setCurrentUser(user);
  }, [user, navigate, setCurrentUser]);
  
  if (!user) {
    return null; // Return null or a loading state, the useEffect will handle redirection
  }
  
  const baseUrl = "https://101000.shop/92af22c7480006e3af1d/2bb8de396d/?placementName=";
  
  const handleImpressionClick = () => {
    const fullUrl = `${baseUrl}${user.username}`;
    window.open(fullUrl, "_blank");
  };
  
  const handleSignupClick = () => {
    const fullUrl = `${baseUrl}${user.username}`;
    window.open(fullUrl, "_blank");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cpm-green to-cpm-black text-white">
      <BackButton />
      <div className="w-full max-w-md mx-auto text-center p-6">
        <h1 className="text-4xl font-bold mb-6">Cpm Work Online</h1>
        
        <Logo />
        
        <div className="mt-8 mb-10 space-y-4">
          <h2 className="text-2xl font-semibold">{user.fullName}</h2>
          <p className="text-lg">Username: {user.username}</p>
          <p className="text-md">Registration #: {user.id}</p>
        </div>
        
        <div className="space-y-4">
          <button 
            onClick={handleImpressionClick}
            className="block w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Impression
          </button>
          
          <button 
            onClick={handleSignupClick}
            className="block w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Sign_up
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileDetails;
