
import { useUser } from "@/context/UserContext";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import BackButton from "@/components/BackButton";

const UserList = () => {
  const { users } = useUser();

  return (
    <div className="min-h-screen bg-gradient-to-r from-cpm-blue to-cpm-black text-white p-6">
      <BackButton />
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">User Lists</h1>
        
        <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-white">ID</TableHead>
                <TableHead className="text-white">Full Name</TableHead>
                <TableHead className="text-white">Username</TableHead>
                <TableHead className="text-white">Bkash Number</TableHead>
                <TableHead className="text-white">Placement Link</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length > 0 ? (
                users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="text-white">{user.id}</TableCell>
                    <TableCell className="text-white">{user.fullName}</TableCell>
                    <TableCell className="text-white">{user.username}</TableCell>
                    <TableCell className="text-white">{user.bkashNumber || "N/A"}</TableCell>
                    <TableCell className="text-white">
                      <a 
                        href={`https://101000.shop/92af22c7480006e3af1d/2bb8de396d/?placementName=${user.username}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:underline"
                      >
                        View Link
                      </a>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-white">
                    No users registered yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default UserList;
