
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "@/components/ui/use-toast";
import BackButton from "@/components/BackButton";

const AdminLogin = () => {
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password === "373324") {
      // Admin login successful
      navigate("/admin/users");
    } else {
      // Incorrect password
      toast({
        title: "Error",
        description: "Incorrect password. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-cpm-blue to-cpm-black text-white">
      <BackButton />
      <div className="w-full max-w-md mx-auto p-6">
        <h1 className="text-3xl font-bold text-center mb-8">Admin Panel</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 rounded-md border border-gray-600 bg-gray-800 text-white"
              placeholder="Enter admin password"
            />
          </div>
          
          <button
            type="submit"
            className="w-full py-3 px-6 bg-cpm-yellow text-black font-bold rounded-lg hover:bg-yellow-400 transition-colors"
          >
            Confirm
          </button>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;
