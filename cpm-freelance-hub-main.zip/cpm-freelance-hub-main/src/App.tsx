
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import Registration from "./pages/Registration";
import SearchProfile from "./pages/SearchProfile";
import ProfileDetails from "./pages/ProfileDetails";
import NotFound from "./pages/NotFound";
import AdminLogin from "./pages/AdminLogin";
import UserList from "./pages/UserList";
import { UserProvider } from "./context/UserContext";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <UserProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/registration" element={<Registration />} />
            <Route path="/search" element={<SearchProfile />} />
            <Route path="/profile/:username" element={<ProfileDetails />} />
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/admin/users" element={<UserList />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </UserProvider>
  </QueryClientProvider>
);

export default App;
