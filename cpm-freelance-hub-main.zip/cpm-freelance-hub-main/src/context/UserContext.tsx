
import { createContext, useContext, useState, useEffect, ReactNode } from "react";

type User = {
  id: number;
  fullName: string;
  username: string;
  bkashNumber?: string;
};

type UserContextType = {
  users: User[];
  addUser: (user: Omit<User, "id">) => User;
  findUser: (username: string) => User | undefined;
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
};

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Load saved users from localStorage on component mount
  useEffect(() => {
    const savedUsers = localStorage.getItem("cpmUsers");
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    }
  }, []);

  // Save users to localStorage whenever the users array changes
  useEffect(() => {
    localStorage.setItem("cpmUsers", JSON.stringify(users));
  }, [users]);

  const addUser = (user: Omit<User, "id">) => {
    const newUser = {
      ...user,
      id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1
    };
    setUsers(prev => [...prev, newUser]);
    return newUser;
  };

  const findUser = (username: string) => {
    return users.find(user => user.username === username);
  };

  return (
    <UserContext.Provider value={{ users, addUser, findUser, currentUser, setCurrentUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
